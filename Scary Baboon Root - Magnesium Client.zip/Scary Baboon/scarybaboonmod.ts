declare const Il2Cpp: any;
declare const console: any;
declare const System: any;
declare const XRNode: any;
declare const Random: any;
declare const UnityEngine: any;

let rigidbody = null

let thingforfling = null

let hue = 0;

let lastRunTime = 0;
const strobecooldown = 300;
const rgbcooldown = 300;
const destroycooldown = 250;

let invisible = false

let buttonClickDelay = 0.0;
let menu = null;
let reference = null;
let referenceCollider = null;

let leftPrimary = false;
let leftSecondary = false;

let rightPrimary = false;
let rightSecondary = false;

let leftGrab = false;
let rightGrab = false;

let leftTrigger = false;
let rightTrigger = false;

let deltaTime = 0.0;
let time = 0.0;

let previousGhostKey = false;
let previousInvisKey = false;
let previousNoclipKey = false;
let perviousTeleportKey = false;

let closePosition = null;
let tagGunDelay = 0.0;

let leftPlatform = null;
let rightPlatform = null;

let lvT = null;
let rvT = null;

let bgColor: [number, number, number, number] = [0.412, 0.412, 0.412, 1.0];
let bgColor2: [number, number, number, number] = [0.231, 0.231, 0.231, 1.0];
let textColor: [number, number, number, number] = [1.0, 1.0, 1.0, 1.0];
let buttonColor: [number, number, number, number] = [0.6, 0.6, 0.6, 1.0];
let buttonPressedColor: [number, number, number, number] = [1.0, 0.0, 0.0, 1.0];

let menuName: string = "Magnesium Client";
let themeIndex = 0;
class XRInputHandler {
    private InputDevices: any;
    private tryGetFeatureValue: any;
    private buttonStates: Map<string, boolean>;

    constructor() {
        this.InputDevices = Il2Cpp.domain
            .assembly("UnityEngine.XRModule")
            .image.class("UnityEngine.XR.InputDevices");

        this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
        this.buttonStates = new Map();
    }

    update() {
        this.updateControllerStates(1); // left controller
        this.updateControllerStates(2); // right controller
    }

    private updateControllerStates(controllerId: number) {
        const features = [
            "PrimaryButton",
            "SecondaryButton",
            "GripButton",
            "TriggerButton",
            "MenuButton"
        ];

        features.forEach(feature => {
            const key = `${controllerId}_${feature}`;
            this.buttonStates.set(key, this.getButtonState(controllerId, feature));
        });
    }

    private getButtonState(deviceId: number, featureName: string): boolean {
        try {
            const valuePtr = Il2Cpp.alloc(1);
            const feature = Il2Cpp.string(featureName);
            const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
            if (success) {
                return valuePtr.readU8() !== 0;
            }
        } catch (_) { }
        return false;
    }

    isButtonPressed(controllerId: number, feature: string): boolean {
        return this.buttonStates.get(`${controllerId}_${feature}`) || false;
    }

    // Renamed getters
    get leftControllerPrimaryButton(): boolean { return this.isButtonPressed(1, "PrimaryButton"); }
    get leftControllerSecondaryButton(): boolean { return this.isButtonPressed(1, "SecondaryButton"); }
    get rightControllerPrimaryButton(): boolean { return this.isButtonPressed(2, "PrimaryButton"); }
    get rightControllerSecondaryButton(): boolean { return this.isButtonPressed(2, "SecondaryButton"); }
    get leftGrab(): boolean { return this.isButtonPressed(1, "GripButton"); }
    get rightGrab(): boolean { return this.isButtonPressed(2, "GripButton"); }
    get leftControllerTriggerButton(): boolean { return this.isButtonPressed(1, "TriggerButton"); }
    get rightControllerTriggerButton(): boolean { return this.isButtonPressed(2, "TriggerButton"); }
    get controllerMenuButton(): boolean {
        return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
    }
}

Il2Cpp.perform(() => {
    const images = {
        "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
        "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
        "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
        "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
        "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
        "UnityEngine": Il2Cpp.domain.assembly("UnityEngine").image,
        "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
        "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image
    };
    const AssemblyCSharp = images["Assembly-CSharp"];
    const UnityEngineCore = images["UnityEngine.CoreModule"];
    const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
    const UnityEngineUI = images["UnityEngine.UI"];
    const UnityEngineUIModule = images["UnityEngine.UIModule"];
    const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
    const PhotonUnityNetworking = images["PhotonUnityNetworking"];

    const GTPlayerClass = AssemblyCSharp.class("GorillaLocomotion.Player");
    const GorillaReportButton = AssemblyCSharp.class("BaboonButton");
    const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");
    const GTPlayer = GTPlayerClass.method("get_Instance").invoke();
    const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
    const Object = UnityEngineCore.class("UnityEngine.Object");
    const Component = UnityEngineCore.class("UnityEngine.Component");
    const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
    const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
    const Time = UnityEngineCore.class("UnityEngine.Time");
    const Resources = UnityEngineCore.class("UnityEngine.Resources");
    const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
    const Shader = UnityEngineCore.class("UnityEngine.Shader");
    const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
    const MeshCollider = UnityEnginePhysics.class("UnityEngine.Collider");
    const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
    const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
    const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
    const Physics = UnityEnginePhysics.class("UnityEngine.Physics");

    const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
    const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
    const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
    const Text = UnityEngineUI.class("UnityEngine.UI.Text");
    const Font = UnityEngineTextRendering.class("UnityEngine.Font");
    const GorillaTagger = GTPlayer

    // Scary Baboon Classes
    const NetworkPlayerSpawnerClass = AssemblyCSharp.class("NetworkPlayerSpawner");
    const NetworkPlayer = AssemblyCSharp.class("NetworkPlayer");

    for (const field of GTPlayerClass.fields) {
        if (field.type.name == "UnityEngine.Rigidbody") {
            rigidbody = GTPlayer.field(field.name).value
        }
    }

    const UberShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Lit"));
    const TextShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));

    const zeroVector = Vector3.field("zeroVector").value;
    const oneVector = Vector3.field("oneVector").value;
    const identityQuaternion = Quaternion.field("identityQuaternion").value;

    const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
    const rightHandTransform = GorillaTagger.field("rightHandTransform").value;
    const headCollider = GorillaTagger.field("headCollider").value;

    const OVRInputHandler = new XRInputHandler();

    const arial = Resources
        .method("GetBuiltinResource", 1)
        .inflate(Font)
        .invoke(Il2Cpp.string("Arial.ttf"));

    function Destroy(object) {
        Object.method("Destroy", 1).invoke(object);
    }

    function getComponent(obj: any, type) {
        return obj.method("GetComponent", 1).inflate(type).invoke();
    }

    function addComponent(obj: any, type) {
        return obj.method("AddComponent", 1).inflate(type).invoke();
    }

    function getComponentInParent(obj: any, type) {
        return obj.method("GetComponentInParent", 0).inflate(type).invoke();
    }

    function getTransform(obj: any) {
        return obj.method("get_transform").invoke();
    }

    function sendAllOutgoing() {
        PhotonNetwork.method("SendAllOutgoingCommands").invoke();
    }

    function renderMenuText(
        canvasObject,
        text: string = "",
        color: [number, number, number, number] = [1, 1, 1, 1],
        pos = zeroVector,
        size = oneVector
    ) {
        const title = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Text);
        getComponent(title, BoxCollider).method("set_isTrigger").invoke(true);
        title.method("set_text").invoke(Il2Cpp.string(text));
        title.method("set_font").invoke(arial);
        title.method("set_fontSize").invoke(1);
        title.method("set_color").invoke(color);
        title.method("set_fontStyle").invoke(3);
        title.method("set_alignment").invoke(4);
        title.method("set_resizeTextForBestFit").invoke(true);
        title.method("set_resizeTextMinSize").invoke(0);

        const rectTransform = getComponent(title, RectTransform);
        rectTransform.method("set_sizeDelta").invoke(size);
        rectTransform.method("set_position").invoke(pos);
        rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0))
    }
    function createObject(
        pos = zeroVector,
        rot = identityQuaternion,
        scale = oneVector,
        primitiveType: number = 3,
        colorArr: [number, number, number, number] = [1, 1, 1, 1],
        parent = null
    ) {
        const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);

        const renderer = getComponent(obj, Renderer);

        if (colorArr[3] == 0) {
            renderer.method("set_enabled").invoke(false);
        } else {
            const material = renderer.method("get_material").invoke();
            material.method("set_shader").invoke(UberShader);
            material.method("set_color").invoke(colorArr);
        }

        const transform = getTransform(obj);
        if (parent != null) {
            transform.method("SetParent", 2).invoke(parent, false);
        }

        transform.method("set_position").invoke(pos);
        transform.method("set_rotation").invoke(rot);
        transform.method("set_localScale").invoke(scale);

        return obj;
    }

    //#region Mods

    //#region  Movement

    let platColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
    const platColors: [number, number, number, number][] = [
        [0.0, 0.0, 0.0, 1.0],       // Black
        [9.0, 9.0, 9.0, 1.0],       // Bright white
        [9.0, 0.0, 0.0, 1.0],       // Red
        [0.0, 9.0, 0.0, 1.0],       // Green
        [0.0, 0.0, 9.0, 1.0],       // Blue
        [5.0, 5.0, 0.0, 1.0],       // Yellow
        [9.0, 0.5, 9.0, 1.0],       // Magenta
    ];
    let platL = null;
    let platR = null;
    let plater = 0;

    function Platforms() {
        if (leftGrab) {
            if (platL == null) {
                const handTransform = leftHandTransform;
                platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platL != null) {
                Destroy(platL);
                platL = null;
            }
        }

        if (rightGrab) {
            if (platR == null) {
                const handTransform = rightHandTransform;
                platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platR != null) {
                Destroy(platR);
                platR = null;
            }
        }
    }

    function TriggerPlatforms() {
    if (leftTrigger) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightTrigger) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  function PlankPlatforms() {
    if (leftGrab) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightGrab) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  let orbitCenter: any = null;
  let orbitAngle = 0;

  function flingUp(force: number = 35) {
    const velocity = new Vector3(
      0,
      force,
      0
    );

    rigidbody.method("set_velocity").invoke(velocity);
  }

  function flingRight(force: number = 35) {
    const velocity = new Vector3(
      force,
      0,
      0
    );

    rigidbody.method("set_velocity").invoke(velocity);
  }

  function flingLeft(force: number = 35) {
    const velocity = new Vector3(
      -force,
      0,
      0
    );

    rigidbody.method("set_velocity").invoke(velocity);
  }

  function flingForward(force: number = 35) {
    const velocity = new Vector3(
      0,
      0,
      force
    );

    rigidbody.method("set_velocity").invoke(velocity);
  }

  function flingBackward(force: number = 35) {
    const velocity = new Vector3(
      0,
      0,
      -force
    );

    rigidbody.method("set_velocity").invoke(velocity);
  }

  function circleFly() {
    if (orbitCenter == null) {
      orbitCenter = rigidbody.method("get_position").invoke();
    }

    orbitAngle += 0.03;

    const radius = 5;

    const target = new Vector3(
      orbitCenter.x + Math.cos(orbitAngle) * radius,
      orbitCenter.y,
      orbitCenter.z + Math.sin(orbitAngle) * radius
    );

    const current = rigidbody.method("get_position").invoke();

    const velocity = Vector3.method("op_Subtraction").invoke(target, current);

    rigidbody.method("set_velocity").invoke(
      Vector3.method("op_Multiply", 2).invoke(velocity, 6)
    );
  }

  function TriggerPlankPlatforms() {
    if (leftTrigger) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightTrigger) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

    //#endregion

    //#region  Server
    function getLocalNetworkPlayer() {
        try {
            const allNetworkPlayers = Object.method("FindObjectsOfType").inflate(NetworkPlayer).invoke();

            const localPhotonPlayer = PhotonNetwork.method("get_LocalPlayer").invoke();
            const localPlayerId = localPhotonPlayer.method("get_UserId").invoke().toString();

            for (let i = 0; i < allNetworkPlayers.length; i++) {
                const networkPlayer = allNetworkPlayers.get(i);
                try {
                    const photonView = networkPlayer.field("photonView").value;
                    if (photonView != null) {
                        const owner = photonView.method("get_Owner").invoke();
                        if (owner != null) {
                            const ownerId = owner.method("get_UserId").invoke().toString();
                            if (ownerId === localPlayerId) {
                                return networkPlayer;
                            }
                        }
                    }
                } catch (e) {
                    continue;
                }
            }

            return null;
        } catch (e) {
            return null;
        }
    }

    function ClearRPC() {
        const LocalPlayer = PhotonNetwork.property("LocalPlayer").getValue(null);
        PhotonNetwork.method("RemoveRPCs", 1).invoke(null, LocalPlayer);
        PhotonNetwork.method("RemoveBufferedRPCs", 0).invoke(null);
        PhotonNetwork.field("MaxResendsBeforeDisconnect").value = 2147483647;
        PhotonNetwork.field("QuickResends").value = 2147483647;
        sendAllOutgoing()
    }
    //#endregion

    //#endregion

    function renderMenu() {
        menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
        Destroy(getComponent(menu, BoxCollider))

        const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, bgColor, getTransform(menu))
        Destroy(getComponent(menuBackground, BoxCollider))

        const menuBackground2 = createObject([0.1, 0, 0], identityQuaternion, [0.09, 0.88, 0.72], 3, bgColor2, getTransform(menu))
        Destroy(getComponent(menuBackground2, BoxCollider))

        const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
        const canvas = addComponent(canvasObject, Canvas);
        Destroy(getComponent(canvasObject, BoxCollider))

        const canvasScaler = addComponent(canvasObject, CanvasScaler);
        addComponent(canvasObject, GraphicRaycaster);
        canvas.method("set_renderMode").invoke(2);
        canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);

        const homeButton = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const homeButton2 = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        homeButton.method("set_name").invoke(Il2Cpp.string("@Home"));

        addComponent(homeButton, GorillaReportButton);
        getComponent(homeButton, BoxCollider).method("set_isTrigger").invoke(true);

        renderMenuText(canvasObject, "Home", textColor, [0.105, -0.06, 0.205], [0.15, 0.15]);

        const leaveButton = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const leaveButton2 = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        leaveButton.method("set_name").invoke(Il2Cpp.string("@Leave"));

        addComponent(leaveButton, GorillaReportButton);
        getComponent(leaveButton, BoxCollider).method("set_isTrigger").invoke(true);

        renderMenuText(canvasObject, "Join Pub", textColor, [0.105, 0.06, 0.205], [0.15, 0.15]);

        renderMenuText(canvasObject, menuName + ` - Page [ <color=cyan>${currentPage + 1} </color>]`, textColor, [0.11, 0, 0.155], [1, .1]);
        {
            const pageButton = createObject([0.1, 0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, 0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));


            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, "<", textColor, [0.11, 0.17, 0], [1, 0.1]);
        }

        {
            const pageButton = createObject([0.1, -0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, -0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));


            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, ">", textColor, [0.11, -0.17, 0], [1, 0.1]);
        }

        let i = 0;
        const targetMods = buttons[currentCategory]
            .slice(currentPage * 6)
            .slice(0, 6);

        targetMods.forEach((buttonData) => {
            const button = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.09, 0.8, 0.08], 3, buttonColor, getTransform(menu));
            button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));

            addComponent(button, GorillaReportButton);
            getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, buttonData.buttonText, textColor, [0.11, 0, 0.11 - (i * 0.04)], [1, 0.1]);
            updateButtonColor(button, buttonData);
            i++;
        });

        recenterMenu();
    }

    function renderReference() {
        reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor2, rightHandTransform)
        referenceCollider = getComponent(reference, Collider);

        getTransform(reference).method("set_localPosition").invoke([0.01, 0, 0.2]);
        reference.method("set_layer").invoke(2);
        addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
    }

    let gunLocked = false;
    let lockTarget = null;
    let GunPointer = null;
    let GunLine = null;
    function renderGun(overrideLayerMask = null) {
        const StartPosition = rightHandTransform.method("get_position").invoke();
        const Direction = rightHandTransform.method("get_forward").invoke();

        const DirectionDivided = Vector3.method("op_Division").invoke(Direction, 4);
        const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionDivided);

        const layerMask = overrideLayerMask || -3180559;

        const hits = Physics.method("RaycastAll", 4).invoke(
            rayStartPosition,  // origin (Vector3)
            Direction,         // direction (Vector3)
            512.0,            // maxDistance (float)
            layerMask         // layerMask (int)
        );

        let finalDistance = Infinity;
        let finalRay = null;
        for (const hit of hits) {
            const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
            if (distance < finalDistance) {
                finalRay = hit;
                finalDistance = distance;
            }
        }

        let EndPosition;
        if (gunLocked) {
            EndPosition = getTransform(lockTarget).method("get_position").invoke();
        } else {
            EndPosition = finalRay.method("get_point").invoke();
        }

        if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
            const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
            EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
        }

        if (GunPointer == null) {
            GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
        }

        GunPointer.method("SetActive").invoke(true);
        const pointerTransform = getTransform(GunPointer);
        pointerTransform.method("set_position").invoke(EndPosition);

        const PointerRenderer = getComponent(GunPointer, Renderer);
        const material = PointerRenderer.method("get_material").invoke();

        material.method("set_shader").invoke(TextShader);

        const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
        material.method("set_color").invoke(pointerColor);

        const collider = getComponent(GunPointer, Collider);
        if (collider != null) {
            Destroy(collider);
        }


        if (rightTrigger || gunLocked) {
            const Step = 10;
            for (let i = 1; i < (Step - 1); i++) {
                const t = i / (Step - 1);
                const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);

                const randomValue = Math.random();
                let offset = zeroVector;

                if (randomValue > 0.75) {
                    offset = [
                        (Math.random() * 0.2) - 0.1,
                        (Math.random() * 0.2) - 0.1,
                        (Math.random() * 0.2) - 0.1
                    ];
                }

            }

        }

        return { ray: finalRay, gunPointer: GunPointer };
    }

    function recenterMenu() {
        let menuPosition = leftHandTransform.method("get_position").invoke();
        let menuRotation = leftHandTransform.method("get_rotation").invoke();

        menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(-45, 0, 0))

        const menuTransform = getTransform(menu);
        menuTransform.method("set_position").invoke(menuPosition);
        menuTransform.method("set_rotation").invoke(menuRotation);
    }

    function reloadMenu() {
        if (menu != null) {
            Object.method("Destroy", 1).invoke(menu);
            menu = null;
        }
    }

    function updateButtonColor(button, buttonData) {
        const RendererClass = Il2Cpp.domain
            .assembly("UnityEngine.CoreModule")
            .image
            .class("UnityEngine.Renderer");

        const renderer = getComponent(button, RendererClass);
        if (!renderer) {
            return;
        }

        const material = renderer.method("get_material").invoke();
        material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
    }

    function toggleColliders(enabled) {
        const meshColliders = Object.method("FindObjectsOfType").inflate(MeshCollider).invoke();

        for (let i = 0; i < meshColliders.length; i++) {
            const meshCollider = meshColliders.get(i);
            meshCollider.method("set_enabled").invoke(enabled);
        }
    }

    interface ButtonInfoConfig {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn?: boolean;
        enabled?: boolean;
    }

    class ButtonInfo {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn: boolean;
        enabled: boolean;

        constructor(config: ButtonInfoConfig) {
            this.buttonText = config.buttonText;
            this.method = config.method;
            this.enableMethod = config.enableMethod;
            this.disableMethod = config.disableMethod;
            this.keepOn = config.keepOn ?? true;
            this.enabled = config.enabled ?? false;
        }
    }

    function hsl2Rgb(h, s, l) {
    s /= 100;
    l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [
      Math.round(255 * f(0)),
      Math.round(255 * f(8)),
      Math.round(255 * f(4))
    ];
  }

  function getSmoothColor() {
    hue = (hue + 0.5) % 360;
    const [r, g, b] = hsl2Rgb(hue, 100, 50);
    return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
  }

  function rainRigs() {
    const center = rigidbody.method("get_position").invoke();

    const pos = new Vector3(
        center.x + (Math.random() - 0.5) * 10,
        center.y + 1,
        center.z + (Math.random() - 0.5) * 10
    );
    const spawnedRainGun = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFling"), pos, identityQuaternion, 0, NULL)
    sendAllOutgoing()
    ClearRPC()
  }

  function rainPistols() {
    const center = rigidbody.method("get_position").invoke();

    const pos = new Vector3(
        center.x + (Math.random() - 0.5) * 10,
        center.y + 1,
        center.z + (Math.random() - 0.5) * 10
    );
    const spawnedRainGun = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("PistolCommon"), pos, identityQuaternion, 0, NULL)
    sendAllOutgoing()
    ClearRPC()
  }

  function randomItem(list: string[]) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function rainShotguns() {
    const center = rigidbody.method("get_position").invoke();

    const guns = randomItem(["PistolCommon", "ShotgunCommon", "SMGCommon", "ScarCommon", "GrenadeLauncherCommon", "SniperCommon"]);

    const pos = new Vector3(
        center.x + (Math.random() - 0.5) * 10,
        center.y + 1,
        center.z + (Math.random() - 0.5) * 10
    );
    const spawnedRainGun = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(guns), pos, identityQuaternion, 0, NULL)
    sendAllOutgoing()
    ClearRPC()
  }

  function getOrbitPosition(radius = 2) {
    const center = rigidbody.method("get_position").invoke();

    const now = Date.now();
    const angle = now * 0.002;

    return new Vector3(
      center.x + Math.cos(angle) * radius,
      center.y,
      center.z + Math.sin(angle) * radius
    );
  }

  function orbitShotguns() {
    const center = rigidbody.method("get_position").invoke();

    const guns = randomItem(["PistolCommon", "ShotgunCommon", "SMGCommon", "ScarCommon", "GrenadeLauncherCommon", "SniperCommon"]);

    const pos = getOrbitPosition(1)
    const spawnedOrbitGun = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(guns), pos, identityQuaternion, 0, NULL)
    sendAllOutgoing()
    ClearRPC()
  }

  function orbitShotgunsSmallRadius() {
    const center = rigidbody.method("get_position").invoke();

    const guns = randomItem(["PistolCommon", "ShotgunCommon", "SMGCommon", "ScarCommon", "GrenadeLauncherCommon", "SniperCommon"]);

    const pos = getOrbitPosition(0.5)
    const spawnedOrbitGun = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(guns), pos, identityQuaternion, 0, NULL)
    sendAllOutgoing()
    ClearRPC()
  }
  function orbitShotgunsBigRadius() {
    const center = rigidbody.method("get_position").invoke();

    const guns = randomItem(["PistolCommon", "ShotgunCommon", "SMGCommon", "ScarCommon", "GrenadeLauncherCommon", "SniperCommon"]);

    const pos = getOrbitPosition(2);
    const spawnedOrbitGun = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(guns), pos, identityQuaternion, 0, NULL);
    sendAllOutgoing();
    ClearRPC();
  }
  function SpamGuns() {

    const guns = randomItem(["PistolCommon", "ShotgunCommon", "SMGCommon", "ScarCommon", "GrenadeLauncherCommon", "SniperCommon"]);

    const pos = getOrbitPosition(2);
    const spawnedOrbitGun = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(guns), pos, identityQuaternion, 0, NULL);
    sendAllOutgoing();
    ClearRPC();
  }

    let currentCategory = 0;
    let currentPage = 0;
    let flyspeed = 5.0;
    let ghost = false;

    const buttons: ButtonInfo[][] = [
        [ // Home
            new ButtonInfo({
                buttonText: "Settings",
                method: () => currentCategory = 2,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Movement Mods",
                method: () => currentCategory = 3,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Broken Mods",
                method: () => currentCategory = 4,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "OP Mods",
                method: () => currentCategory = 5,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Prefab Mods",
                method: () => currentCategory = 6,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Sound Mods + Effects",
                method: () => currentCategory = 7,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Monster Mods",
                method: () => { currentCategory = 8, currentPage = 0 },
                keepOn: false,
            }),
        ],
        [ // Menu Buttons
            new ButtonInfo({
                buttonText: "Leave",
                method: () => PhotonNetwork.method("LeaveRoom", 1).invoke(true),
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Home",
                method: () => {
                    currentCategory = 0
                    currentPage = 0
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PreviousPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

                    currentPage--;
                    if (currentPage < 0)
                        currentPage = lastPage;
                },
                keepOn: false
            }),
            new ButtonInfo({
                buttonText: "NextPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

                    currentPage++;
                    currentPage %= lastPage + 1;
                },
                keepOn: false
            })
        ],
        [ // Settings
            new ButtonInfo({
                buttonText: `Fly Speed+`,
                method: () => {
                    flyspeed += 1;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: `Fly Speed-`,
                method: () => {
                    flyspeed -= 1;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: `Fly Speed++`,
                method: () => {
                    flyspeed += 2;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: `Fly Speed--`,
                method: () => {
                    flyspeed -= 2;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Platform Color",
                method: () => {
                    plater = (plater + 1) % platColors.length;
                    platColor = platColors[plater];
                },
                keepOn: false
            }),
        ],
        [ // Movement Mods
            new ButtonInfo({
                buttonText: "Fly [B]",
                method: () => {
                    if (rightSecondary) {
                        const leftRightVector = rightHandTransform.method("get_forward").invoke();
                        const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, flyspeed);
                        rigidbody.method("set_velocity").invoke(leftForce);
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Trigger Fly [RT]",
                method: () => {
                    if (rightTrigger) {
                        const leftRightVector = rightHandTransform.method("get_forward").invoke();
                        const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, flyspeed);
                        rigidbody.method("set_velocity").invoke(leftForce);
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Platforms [G]",
                method: () => {
                    Platforms()
                },
            }),

            new ButtonInfo({
                buttonText: "Trigger Platforms [T]",
                method: () => {
                    TriggerPlatforms()
                },
            }),

            new ButtonInfo({
                buttonText: "Plank Platforms [G]",
                method: () => {
                    PlankPlatforms()
                },
            }),

            new ButtonInfo({
                buttonText: "Trigger Plank Platforms [T]",
                method: () => {
                    TriggerPlankPlatforms()
                },
            }),

            new ButtonInfo({
                buttonText: "No Clip",
                method: () => {
                    if (rightTrigger && !previousNoclipKey) {
                        toggleColliders(false);
                    }

                    if (!rightTrigger && previousNoclipKey) {
                        toggleColliders(true);
                    }

                    previousNoclipKey = rightTrigger;
                },
            }),
            new ButtonInfo({
                buttonText: "Ghost Monkey",
                method: () => {
                    if (rightSecondary) {
                        const now = Date.now();
                        if (now - lastRunTime >= 500) { // 500ms = 0.5 seconds
                            lastRunTime = now;
                            ghost = !ghost;

                            const localNetworkPlayer = getLocalNetworkPlayer();
                            if (localNetworkPlayer != null) {
                                localNetworkPlayer.method("set_enabled").invoke(!ghost);
                            }
                        }
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Fling Up",
                method: () => {
                    flingUp(35)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Fling Left",
                method: () => {
                    flingLeft(35)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Fling Right",
                method: () => {
                    flingRight(35)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Fling Forward",
                method: () => {
                    flingForward(35)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Fling Backward",
                method: () => {
                    flingBackward(35)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Strong Fling Up",
                method: () => {
                    flingUp(70)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Strong Fling Left",
                method: () => {
                    flingLeft(70)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Strong Fling Right",
                method: () => {
                    flingRight(70)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Strong Fling Forward",
                method: () => {
                    flingForward(70)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Strong Fling Backward",
                method: () => {
                    flingBackward(70)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Weak Fling Up",
                method: () => {
                    flingUp(15)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Weak Fling Left",
                method: () => {
                    flingLeft(15)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Weak Fling Right",
                method: () => {
                    flingRight(15)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Weak Fling Forward",
                method: () => {
                    flingForward(15)
                },
                keepOn: false
            }),

            new ButtonInfo({
                buttonText: "Weak Fling Backward",
                method: () => {
                    flingBackward(15)
                },
                keepOn: false
            }),
        ],
        [ // Misc Mods
            new ButtonInfo({
                buttonText: "Open Staff",
                method: () => {
                    Destroy(GameObject.method("Find").invoke(Il2Cpp.string("Mod")));
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Byteful Name",
                method: () => {
                    const name = "<size=100><sprite=12>Byteful<sprite=12>"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "RGB",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime >= rgbcooldown) {
                        lastRunTime = now;
                        NetworkPlayerSpawnerClass.method("SetColor").invoke([Math.random(), Math.random(), Math.random(), 1.0])
                    }
                },
                keepOn: true,
            }),

            new ButtonInfo({
                buttonText: "Spam Random Color",
                method: () => {
                    const now = Date.now();
                    NetworkPlayerSpawnerClass.method("SetColor").invoke([Math.random(), Math.random(), Math.random(), 1.0])
                },
                keepOn: true,
            }),

            new ButtonInfo({
                buttonText: "Big Name",
                method: () => {
                    const name = "<size=170%><sprite=12>ByteMods On Top!<sprite=12>"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Blinding Name",
                method: () => {
                    const name = "<size=170%>|||||||||||||||||||||||||||||||||||||||||"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Small Name",
                method: () => {
                    const name = "<size=50%><sprite=12>ByteMods On Top!<sprite=12>"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "No Name",
                method: () => {
                    const name = "<size=1>"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

        ],
        [ // OP Mods
            new ButtonInfo({
                buttonText: "Set Master",
                method: () => {
                    PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Rig Spam",
                method: () => {
                    if (rightSecondary) {
                        const now = Date.now();
                        if (now - lastRunTime >= 0.1) {
                            lastRunTime = now;
                            const clonedrig = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonNetworkPlayer_SquidGame"), getTransform(headCollider).method("get_position").invoke(), identityQuaternion, 0, NULL)
                            const components = clonedrig.method("GetComponents", 0).inflate(Component).invoke();

                            for (let i = 0; i < components.length; i++) {
                                const component = components.get(i);
                                const name = component.method("GetType", 0).invoke().method("get_Name").invoke().toString();

                                if (name.includes("BaboonNetworkPlayer_SquidGame")) {
                                    setTimeout(function () {
                                        Destroy(component);
                                    }, 150)
                                }
                            }
                        }
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
                keepOn: true,
            }),

            new ButtonInfo({
                buttonText: "Gore Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Fighter Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFighterNetwork"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Miner Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonMiner"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Hammer Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFling"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Baboon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),


            new ButtonInfo({
                buttonText: "Crash All",
                method: () => {
                    for (let i = 0; i < 1500; i++) {
                        const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFighterNetwork"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL)
                        Destroy(thingforlag)
                    }
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Hard Crash All",
                method: () => {
                    for (let i = 0; i < 3000; i++) {
                        const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFighterNetwork"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL)
                        Destroy(thingforlag)
                    }
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Extreme Crash All",
                method: () => {
                    for (let i = 0; i < 7000; i++) {
                        const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFighterNetwork"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL)
                        Destroy(thingforlag)
                    }
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "LagSpike All",
                method: () => {
                    for (let i = 0; i < 100; i++) {
                        const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFighterNetwork"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL)
                        Destroy(thingforlag)
                    }
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Invis All",
                method: () => {
                    const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
                    if (others && others.length > 0) {
                        for (let i = 0; i < others.length; i++) {
                            const player = others.get(i);
                            PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
                            PhotonNetwork.method("DestroyPlayerObjects").invoke(player);
                        }
                    }
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Earrape All [RT]",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("TylerTheCreator"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("AMacrena"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ladyhear"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ImBoutaBombThisPlane"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: true,
            }),

            new ButtonInfo({
                buttonText: "Rain Pistols",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime >= 10)
                    {
                        rainPistols()
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Rain Guns",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime >= 10)
                    {
                        rainShotguns()
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Orbit Guns",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime >= 10)
                    {
                        orbitShotguns()
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Orbit Guns [Small Radius]",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime >= 10)
                    {
                        orbitShotgunsSmallRadius()
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Orbit Guns [Big Radius]",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime >= 10)
                    {
                        orbitShotgunsBigRadius()
                    }
                },
                keepOn: true,
            }),
        ],
        [ // Gun Spawn
            new ButtonInfo({
                buttonText: "SMG",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SMGCommon"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Shotgun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ShotgunCommon"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Scar",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ScarCommon"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Grenade Launcher",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GrenadeLauncherCommon"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Pistol",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("PistolCommon"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Sniper",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SniperCommon"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Spam All Guns",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SniperCommon"), pos, identityQuaternion, 0, NULL)
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("PistolCommon"), pos, identityQuaternion, 0, NULL)
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GrenadeLauncherCommon"), pos, identityQuaternion, 0, NULL)
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ScarCommon"), pos, identityQuaternion, 0, NULL)
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ShotgunCommon"), pos, identityQuaternion, 0, NULL)
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SMGCommon"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Random Gun Spammer",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const gunToSpawn = randomItem(["PistolCommon", "ShotgunCommon", "SMGCommon", "ScarCommon", "GrenadeLauncherCommon", "SniperCommon"]);
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(gunToSpawn), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
        ],
        [ // Effects
            new ButtonInfo({
                buttonText: "Flare [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Flare"), rightHandTransform.method("get_position").invoke(), rightHandTransform.method("get_rotation").invoke(), 0, NULL)
                        sendAllOutgoing()
                        ClearRPC()
                    };;
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Lighting [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Lighting"), pos, [707, 707, 0, 0], 0, NULL)
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Explosion [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigExplosion"), pos, identityQuaternion, 0, NULL)
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Explosion + Lighting [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigExplosion"), pos, identityQuaternion, 0, NULL)
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Lighting"), pos, [707, 707, 0, 0], 0, NULL)
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Confetti Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Confetti"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Macarena Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("AMacrena"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FE!N Song",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "i forgot this song's name",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ladyhear"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "See You Again Song",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("TylerTheCreator"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Tect Talking Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("TectAudio"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Splash Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Plane Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ImBoutaBombThisPlane"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Spam FE!N Song",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Spam Splash Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL)
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Send All Outgoing + Clear RPC",
                method: () => {
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
        ],
        [ // Monster Mods
            new ButtonInfo({
                buttonText: "Big Larry Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/BigLarry"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Meat Man Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/MeatMan"), pos, identityQuaternion, 0, NULL)
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
        ],
    ];

    let buttonMap: Map<string, ButtonInfo> = new Map();
    buttons.flat().forEach(button => {
        buttonMap.set(button.buttonText, button);
    });

    function getIndex(buttonText: string): ButtonInfo {
        return buttonMap.get(buttonText);
    }

    const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
    ButtonActivation.implementation = function (collider) {
        const rawName = this.method("get_name").invoke().toString();

        if (rawName.length > 1 && rawName[1] == "@") {
            if (collider.handle.equals(referenceCollider.handle)) {
                const goName = rawName.substring(2, rawName.length - 1);
                const _time = Time.method("get_time").invoke();

                if (_time > buttonClickDelay) {
                    buttonClickDelay = _time + 0.2;

                    const button = getIndex(goName)
                    if (button) {
                        if (button.keepOn) {
                            button.enabled = !button.enabled;

                            if (button?.enabled) {
                                button.enableMethod?.();
                            } else {
                                button?.disableMethod?.();
                            }

                        } else {
                            button?.method?.();
                        }

                        reloadMenu();
                    }
                }
            }

            return;
        }

        return this.method("OnTriggerEnter").invoke(collider);
    };

    const LateUpdate = GorillaTagger.method("LateUpdate");

    LateUpdate.implementation = function () {

        OVRInputHandler.update();

        leftPrimary = OVRInputHandler.leftControllerPrimaryButton
        leftSecondary = OVRInputHandler.leftControllerSecondaryButton;

        rightPrimary = OVRInputHandler.rightControllerPrimaryButton;
        rightSecondary = OVRInputHandler.rightControllerSecondaryButton;

        leftGrab = OVRInputHandler.leftGrab;
        rightGrab = OVRInputHandler.rightGrab;

        leftTrigger = OVRInputHandler.leftControllerTriggerButton;
        rightTrigger = OVRInputHandler.rightControllerTriggerButton;

        deltaTime = Time.method("get_deltaTime").invoke();
        time = Time.method("get_time").invoke();

        if (leftSecondary) {
            if (menu == null) {
                renderMenu();
            } else {
                recenterMenu();
            }
        } else {
            if (menu != null) {
                Destroy(menu);
                menu = null;
            }
        }

        if (menu == null) {
            if (reference != null) {
                Destroy(reference);
                reference = null;
            }
        } else {
            if (reference == null) {
                renderReference();
            }
        }

        try {
            if (GunPointer != null) {
                if (!(GunPointer.method("get_activeSelf").invoke())) {
                    Destroy(GunPointer);
                    GunPointer = null;
                }
                else
                    GunPointer.method("SetActive").invoke(false);
            }

            let lineObj = GunLine.method("get_gameObject").invoke();
            if (lineObj != null) {
                if (!(lineObj.method("get_activeSelf").invoke())) {
                    Destroy(lineObj);
                    GunLine = null;
                }
                else
                    lineObj.method("SetActive").invoke(false);
            }
        } catch { }

        buttons.flat()
            .filter(button => button.enabled)
            .forEach(button => {
                if (button.method) {
                    try {
                        button.method();
                    } catch (error) {
                        console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
                        console.error('Error stack:', error.stack);
                        console.error('Button object:', button);

                        if (error.stack) {
                            const stackLines = error.stack.split('\n');
                            if (stackLines.length > 1) {
                                console.error('Error occurred at:', stackLines[1].trim());
                            }
                        }
                    }
                }
            });

        return LateUpdate.invoke();
    };
    console.log(`Compiled ${new Date().toISOString()}`);

}, "main");