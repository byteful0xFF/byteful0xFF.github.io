@echo off
echo Starting Frida injection for Meta Game...
echo.

frida -U -l frida-il2cpp-bridge.js -l scarybaboonmod.ts "Baboon"

echo.
echo Frida script execution completed.
echo.
pause
echo Closing...