# heyo thanks for using bytemods root port
# this is specifically for the game "teddys pizzeria" on the meta store
# more than 50 mods
# thats it
# you need root for this btw