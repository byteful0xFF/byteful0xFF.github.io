@echo off
echo Starting Frida injection...
echo.

frida -U -l frida-il2cpp-bridge.js -l TeddysPizzeria_Menu.ts "TeddysPizzeria"

echo.
echo Frida script execution completed.
echo.
pause
echo Closing...

