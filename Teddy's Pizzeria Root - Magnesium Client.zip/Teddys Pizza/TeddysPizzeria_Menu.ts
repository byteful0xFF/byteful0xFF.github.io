declare const Il2Cpp: any;
declare const console: any;
declare const System: any;
declare const XRNode: any;
declare const Random: any;
declare const UnityEngine: any;

let rigidbody = null
let hue = 0;
let lastRunTime = 0;

let buttonClickDelay = 0.0;
let menu = null;
let reference = null;
let referenceCollider = null;

let leftPrimary = false;
let leftSecondary = false;

let rightPrimary = false;
let rightSecondary = false;

let leftGrab = false;
let rightGrab = false;

let leftTrigger = false;
let rightTrigger = false;

let deltaTime = 0.0;
let time = 0.0;

let previousNoclipKey = false;
let perviousDestroyKey = false;

// remember colors are 0 - 1 not 0 - 9 and not 0 - 255.
let bgColor: [number, number, number, number] = [0.412, 0.412, 0.412, 1.0];
let bgColor2: [number, number, number, number] = [0.231, 0.231, 0.231, 1.0];
let textColor: [number, number, number, number] = [1.0, 1.0, 1.0, 1.0];
let buttonColor: [number, number, number, number] = [0.6, 0.6, 0.6, 1.0];
let buttonPressedColor: [number, number, number, number] = [1.0, 0.0, 0.0, 1.0];

let menuName: string = "Magnesium Client";
let themeIndex = 0;
class XRInputHandler {
  private InputDevices: any;
  private tryGetFeatureValue: any;
  private buttonStates: Map<string, boolean>;

  constructor() {
    this.InputDevices = Il2Cpp.domain
      .assembly("UnityEngine.XRModule")
      .image.class("UnityEngine.XR.InputDevices");

    this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
    this.buttonStates = new Map();
  }

  update() {
    this.updateControllerStates(1); // left controller
    this.updateControllerStates(2); // right controller
  }

  private updateControllerStates(controllerId: number) {
    const features = [
      "PrimaryButton",
      "SecondaryButton",
      "GripButton",
      "TriggerButton",
      "MenuButton"
    ];

    features.forEach(feature => {
      const key = `${controllerId}_${feature}`;
      this.buttonStates.set(key, this.getButtonState(controllerId, feature));
    });
  }

  private getButtonState(deviceId: number, featureName: string): boolean {
    try {
      const valuePtr = Il2Cpp.alloc(1);
      const feature = Il2Cpp.string(featureName);
      const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
      if (success) {
        return valuePtr.readU8() !== 0;
      }
    } catch (_) { }
    return false;
  }

  isButtonPressed(controllerId: number, feature: string): boolean {
    return this.buttonStates.get(`${controllerId}_${feature}`) || false;
  }

  get leftControllerPrimaryButton(): boolean { return this.isButtonPressed(1, "PrimaryButton"); }
  get leftControllerSecondaryButton(): boolean { return this.isButtonPressed(1, "SecondaryButton"); }
  get rightControllerPrimaryButton(): boolean { return this.isButtonPressed(2, "PrimaryButton"); }
  get rightControllerSecondaryButton(): boolean { return this.isButtonPressed(2, "SecondaryButton"); }
  get leftGrab(): boolean { return this.isButtonPressed(1, "GripButton"); }
  get rightGrab(): boolean { return this.isButtonPressed(2, "GripButton"); }
  get leftControllerTriggerButton(): boolean { return this.isButtonPressed(1, "TriggerButton"); }
  get rightControllerTriggerButton(): boolean { return this.isButtonPressed(2, "TriggerButton"); }
  get controllerMenuButton(): boolean {
    return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
  }
}

Il2Cpp.perform(() => {
  const images = {
    "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
    "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
    "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
    "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
    "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
    "UnityEngine": Il2Cpp.domain.assembly("UnityEngine").image,
    "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
    "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image,
    "PlayFab": Il2Cpp.domain.assembly("PlayFab").image
  };

  const AssemblyCSharp = images["Assembly-CSharp"];
  const UnityEngineCore = images["UnityEngine.CoreModule"];
  const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
  const UnityEngineUI = images["UnityEngine.UI"];
  const UnityEngineUIModule = images["UnityEngine.UIModule"];
  const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
  const PhotonUnityNetworking = images["PhotonUnityNetworking"];
  const PhotonVRManager = AssemblyCSharp.class("Photon.VR.PhotonVRManager");
  const GTPlayerClass = AssemblyCSharp.class("GorillaLocomotion.Player");
  const GorillaReportButton = AssemblyCSharp.class("SilyGooseTrigger");
  const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");
  const GTPlayer = GTPlayerClass.method("get_Instance").invoke();
  const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
  const Object = UnityEngineCore.class("UnityEngine.Object");
  const Component = UnityEngineCore.class("UnityEngine.Component");
  const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
  const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
  const Time = UnityEngineCore.class("UnityEngine.Time");
  const Resources = UnityEngineCore.class("UnityEngine.Resources");
  const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
  const Shader = UnityEngineCore.class("UnityEngine.Shader");
  const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
  const MeshCollider = UnityEnginePhysics.class("UnityEngine.Collider");
  const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
  const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
  const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
  const Physics = UnityEnginePhysics.class("UnityEngine.Physics");
  const SystemObject = Il2Cpp.corlib.class("System.Object");
  const Animatronics = AssemblyCSharp.class("Animatronics");
  const OfficeDoor = AssemblyCSharp.class("OfficeDoor");

  const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
  const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
  const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
  const Text = UnityEngineUI.class("UnityEngine.UI.Text");
  const Font = UnityEngineTextRendering.class("UnityEngine.Font");
  const GorillaTagger = GTPlayer

  /*Pull Challenge Nonce
  const OculusPlatform = Il2Cpp.domain.assembly("Oculus.Platform").image;
  const CAPI = OculusPlatform.class("Oculus.Platform.CAPI");

  const GetIntegrityToken = CAPI.method("ovr_DeviceApplicationIntegrity_GetIntegrityToken");

  GetIntegrityToken.implementation = function (challenge_nonce) {
    const nonceStr = challenge_nonce ? challenge_nonce.toString() : "";

    console.log("challenge_nonce =", nonceStr);

    return this.method("ovr_DeviceApplicationIntegrity_GetIntegrityToken")
      .invoke(challenge_nonce);
  };*/

  /* Pull Photon Auth Prams
  const PhotonRealtime = Il2Cpp.domain.assembly("PhotonRealtime").image;
  const AuthValues = PhotonRealtime.class("Photon.Realtime.AuthenticationValues");
  const AddAuthParameter = AuthValues.method("AddAuthParameter")

  AddAuthParameter.implementation = function (key, value) {
    const keyStr = key ? key.toString() : "";
    const valueStr = value ? value.toString() : "";

    console.log("[authvalues]", keyStr, valueStr);

    return this.method("AddAuthParameter").invoke(key, value);
  };*/

  for (const field of GTPlayerClass.fields) {
    if (field.type.name == "UnityEngine.Rigidbody") {
      rigidbody = GTPlayer.field(field.name).value
    }
  }

  const MenuShader = Shader.method("Find").invoke(Il2Cpp.string("Unlit/Color"));
  const TextShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));

  const zeroVector = Vector3.field("zeroVector").value;
  const oneVector = Vector3.field("oneVector").value;
  const identityQuaternion = Quaternion.field("identityQuaternion").value;

  const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
  const rightHandTransform = GorillaTagger.field("rightHandTransform").value;
  const headCollider = GorillaTagger.field("headCollider").value;
  let mutationName: string = "None";
  let ovrideBool: boolean;

  const OVRInputHandler = new XRInputHandler();

  const arial = Resources
    .method("GetBuiltinResource", 1)
    .inflate(Font)
    .invoke(Il2Cpp.string("Arial.ttf"));

  function Destroy(object) {
    Object.method("Destroy", 1).invoke(object);
  }

  function getComponent(obj: any, type) {
    return obj.method("GetComponent", 1).inflate(type).invoke();
  }

  function addComponent(obj: any, type) {
    return obj.method("AddComponent", 1).inflate(type).invoke();
  }

  function getComponentInParent(obj: any, type) {
    return obj.method("GetComponentInParent", 0).inflate(type).invoke();
  }

  function getTransform(obj: any) {
    return obj.method("get_transform").invoke();
  }

  function sendAllOutgoing() { PhotonNetwork.method("SendAllOutgoingCommands").invoke(); }

  function hsl2Rgb(h, s, l) {
    s /= 100;
    l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [
      Math.round(255 * f(0)),
      Math.round(255 * f(8)),
      Math.round(255 * f(4))
    ];
  }

  function getSmoothColor() {
    hue = (hue + 0.5) % 360;
    const [r, g, b] = hsl2Rgb(hue, 100, 50);
    return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
  }

  function randomInt(min: number, max: number) {
    return Math.floor(Math.random() * (max - min)) + min;
  }

  function renderMenuText(canvasObject, text: string = "", color: [number, number, number, number] = [1, 1, 1, 1], pos = zeroVector, size = oneVector) {
    const title = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Text);
    getComponent(title, BoxCollider).method("set_isTrigger").invoke(true);
    title.method("set_text").invoke(Il2Cpp.string(text));
    title.method("set_font").invoke(arial);
    title.method("set_fontSize").invoke(1);
    title.method("set_color").invoke(color);
    title.method("set_fontStyle").invoke(3);
    title.method("set_alignment").invoke(4);
    title.method("set_resizeTextForBestFit").invoke(true);
    title.method("set_resizeTextMinSize").invoke(0);

    const rectTransform = getComponent(title, RectTransform);
    rectTransform.method("set_sizeDelta").invoke(size);
    rectTransform.method("set_position").invoke(pos);
    rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0))
  }
  
  function createObject(
    pos = zeroVector,
    rot = identityQuaternion,
    scale = oneVector,
    primitiveType: number = 3,
    colorArr: [number, number, number, number] = [1, 1, 1, 1],
    parent = null
  ) {
    const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);

    const renderer = getComponent(obj, Renderer);

    if (colorArr[3] == 0) {
      renderer.method("set_enabled").invoke(false);
    } else {
      const material = renderer.method("get_material").invoke();
      material.method("set_shader").invoke(MenuShader);
      material.method("set_color").invoke(colorArr);
    }

    const transform = getTransform(obj);
    if (parent != null) {
      transform.method("SetParent", 2).invoke(parent, false);
    }

    transform.method("set_position").invoke(pos);
    transform.method("set_rotation").invoke(rot);
    transform.method("set_localScale").invoke(scale);

    return obj;
  }

  function renderMenu() {
    menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
    Destroy(getComponent(menu, BoxCollider))

    const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, bgColor, getTransform(menu))
    Destroy(getComponent(menuBackground, BoxCollider))

    const menuBackground2 = createObject([0.1, 0, 0], identityQuaternion, [0.09, 0.88, 0.72], 3, bgColor2, getTransform(menu))
    Destroy(getComponent(menuBackground2, BoxCollider))

    const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
    const canvas = addComponent(canvasObject, Canvas);
    Destroy(getComponent(canvasObject, BoxCollider))

    const canvasScaler = addComponent(canvasObject, CanvasScaler);
    addComponent(canvasObject, GraphicRaycaster);
    canvas.method("set_renderMode").invoke(2);
    canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);

    const homeButton = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
    const homeButton2 = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
    homeButton.method("set_name").invoke(Il2Cpp.string("@Home"));

    addComponent(homeButton, GorillaReportButton);
    getComponent(homeButton, BoxCollider).method("set_isTrigger").invoke(true);

    renderMenuText(canvasObject, "Home", textColor, [0.105, -0.06, 0.205], [0.15, 0.15]);

    const leaveButton = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
    const leaveButton2 = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
    leaveButton.method("set_name").invoke(Il2Cpp.string("@Leave"));

    addComponent(leaveButton, GorillaReportButton);
    getComponent(leaveButton, BoxCollider).method("set_isTrigger").invoke(true);

    renderMenuText(canvasObject, "Disconnect", textColor, [0.105, 0.06, 0.205], [0.15, 0.15]);

    renderMenuText(canvasObject, menuName + ` - Page [ <color=cyan>${currentPage + 1} </color>]`, textColor, [0.11, 0, 0.155], [1, .1]);
    {
      const pageButton = createObject([0.1, 0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
      const pageButton2 = createObject([0.1, 0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
      pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));


      addComponent(pageButton, GorillaReportButton);
      getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, "←", textColor, [0.11, 0.17, 0], [1, 0.1]);
    }

    {
      const pageButton = createObject([0.1, -0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
      const pageButton2 = createObject([0.1, -0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
      pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));


      addComponent(pageButton, GorillaReportButton);
      getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, "→", textColor, [0.11, -0.17, 0], [1, 0.1]);
    }

    let i = 0;
    const targetMods = buttons[currentCategory]
      .slice(currentPage * 6)
      .slice(0, 6);


    targetMods.forEach((buttonData) => {
      const button = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.09, 0.8, 0.08], 3, buttonColor, getTransform(menu));
      const button2 = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.08, 0.82, 0.09], 3, bgColor2, getTransform(menu));

      button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));

      addComponent(button, GorillaReportButton);
      getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, buttonData.buttonText, textColor, [0.11, 0, 0.11 - (i * 0.04)], [1, 0.1]);
      updateButtonColor(button, buttonData);
      i++;
    });

    recenterMenu();
  }

  function renderReference() {
    reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor2, rightHandTransform)
    referenceCollider = getComponent(reference, Collider);

    getTransform(reference).method("set_localPosition").invoke([-0.02, 0.0010, 0.165]);
    reference.method("set_layer").invoke(2);
    addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
  }

  let gunLocked = false;
  let lockTarget = null;
  let GunPointer = null;
  let GunLine = null;

  function renderGun(overrideLayerMask = null) {
    const StartPosition = rightHandTransform.method("get_position").invoke();
    const Direction = rightHandTransform.method("get_forward").invoke();

    const DirectionDivided = Vector3.method("op_Division").invoke(Direction, 4);
    const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionDivided);

    const layerMask = overrideLayerMask || -3180559;

    const hits = Physics.method("RaycastAll", 4).invoke(rayStartPosition, Direction, 512.0, layerMask);
    let finalDistance = Infinity;
    let finalRay = null;
    for (const hit of hits) {
      const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
      if (distance < finalDistance) {
        finalRay = hit;
        finalDistance = distance;
      }
    }

    let EndPosition;
    if (gunLocked) {
      EndPosition = getTransform(lockTarget).method("get_position").invoke();
    } else {
      EndPosition = finalRay.method("get_point").invoke();
    }

    if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
      const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
      EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
    }

    if (GunPointer == null) {
      GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
    }

    GunPointer.method("SetActive").invoke(true);
    const pointerTransform = getTransform(GunPointer);
    pointerTransform.method("set_position").invoke(EndPosition);

    const PointerRenderer = getComponent(GunPointer, Renderer);
    const material = PointerRenderer.method("get_material").invoke();

    material.method("set_shader").invoke(TextShader);

    const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
    material.method("set_color").invoke(pointerColor);

    const collider = getComponent(GunPointer, Collider);
    if (collider != null) {
      Destroy(collider);
    }


    if (rightTrigger || gunLocked) {
      const Step = 10;
      for (let i = 1; i < (Step - 1); i++) {
        const t = i / (Step - 1);
        const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);

        const randomValue = Math.random();
        let offset = zeroVector;

        if (randomValue > 0.75) {
          offset = [
            (Math.random() * 0.2) - 0.1,
            (Math.random() * 0.2) - 0.1,
            (Math.random() * 0.2) - 0.1
          ];
        }

      }

    }
    return { ray: finalRay, gunPointer: GunPointer };
  }

  function recenterMenu() {
    let menuPosition = leftHandTransform.method("get_position").invoke();
    let menuRotation = leftHandTransform.method("get_rotation").invoke();

    menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(-45, 0, 0))

    const menuTransform = getTransform(menu);
    menuTransform.method("set_position").invoke(menuPosition);
    menuTransform.method("set_rotation").invoke(menuRotation);
  }

  function reloadMenu() {
    if (menu != null) {
      Object.method("Destroy", 1).invoke(menu);
      menu = null;
    }
  }

  function updateButtonColor(button, buttonData) {
    const RendererClass = Il2Cpp.domain
      .assembly("UnityEngine.CoreModule")
      .image
      .class("UnityEngine.Renderer");

    const renderer = getComponent(button, RendererClass);
    if (!renderer) {
      return;
    }

    const material = renderer.method("get_material").invoke();
    material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
  }

  interface ButtonInfoConfig {
    buttonText: string;
    method?: () => void;
    enableMethod?: () => void;
    disableMethod?: () => void;
    keepOn?: boolean;
    enabled?: boolean;
  }

  class ButtonInfo {
    buttonText: string;
    method?: () => void;
    enableMethod?: () => void;
    disableMethod?: () => void;
    keepOn: boolean;
    enabled: boolean;

    constructor(config: ButtonInfoConfig) {
      this.buttonText = config.buttonText;
      this.method = config.method;
      this.enableMethod = config.enableMethod;
      this.disableMethod = config.disableMethod;
      this.keepOn = config.keepOn ?? true;
      this.enabled = config.enabled ?? false;
    }
  }

  let currentCategory = 0;
  let currentPage = 0;

  //#region Mods

  //#region Player
  let flyspeed = 5.0;
  let ghost = false;
  let riglag = false;
  let strobeycolor = false;
  let lessriglag = false;
  let spawnedRig = null;

  function Fly() {
    if (rightSecondary) {
      rigidbody.method("set_velocity").invoke(Vector3.field("zeroVector").value);

      const transform = getTransform(GorillaTagger);
      let forward = getTransform(rightHandTransform).method("get_forward").invoke();

      let position = transform.method("get_position").invoke();
      forward = Vector3.method("op_Multiply", 2).invoke(forward, flyspeed * deltaTime);

      position = Vector3.method("op_Addition", 2).invoke(position, forward);

      transform.method("set_position").invoke(position);
    }
  }

  function TriggerFly() {
    if (rightTrigger) {
      rigidbody.method("set_velocity").invoke(Vector3.field("zeroVector").value);

      const transform = getTransform(GorillaTagger);
      let forward = getTransform(rightHandTransform).method("get_forward").invoke();

      let position = transform.method("get_position").invoke();
      forward = Vector3.method("op_Multiply", 2).invoke(forward, flyspeed * deltaTime);

      position = Vector3.method("op_Addition", 2).invoke(position, forward);

      transform.method("set_position").invoke(position);
    }
  }

  function GhostRig() {
    if (rightSecondary) {
      const now = Date.now();
      if (now - lastRunTime >= 500) {
        lastRunTime = now;
        ghost = !ghost;
        const getManagerMethod = PhotonVRManager.method("get_Manager");
        const managerInstance = getManagerMethod.invoke();
        const localPlayer = managerInstance.field("LocalPlayer").value;
        localPlayer.method("set_enabled").invoke(!ghost);
      }
    }
  }

  function StrobeName() {
    const now = Date.now();
    if (now - lastRunTime >= 10) {
      lastRunTime = now;
      strobeycolor = !strobeycolor;
      PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(`<color=${strobeycolor ? "#ffffff" : "#000000"}>ByteMods On Top!`))
    }
  }

  function LaggyRig() {
    const now = Date.now();
    if (now - lastRunTime >= 100) {
      lastRunTime = now;
      riglag = !riglag;
      const getManagerMethod = PhotonVRManager.method("get_Manager");
      const managerInstance = getManagerMethod.invoke();
      const localPlayer = managerInstance.field("LocalPlayer").value;
      localPlayer.method("set_enabled").invoke(!ghost);
    }
  }

  function LessLaggyRig() {
    const now = Date.now();
    if (now - lastRunTime >= 50) {
      lastRunTime = now;
      lessriglag = !lessriglag;
      const getManagerMethod = PhotonVRManager.method("get_Manager");
      const managerInstance = getManagerMethod.invoke();
      const localPlayer = managerInstance.field("LocalPlayer").value;
      localPlayer.method("set_enabled").invoke(!ghost);
    }
  }

  function InvisRig() {
    if (rightSecondary) {
      const now = Date.now();
      if (now - lastRunTime >= 500) {
        lastRunTime = now;
        ghost = !ghost;

        if (ghost) {
          if (spawnedRig != null) {
            PhotonNetwork.method("DestroyPlayerObjects").invoke(
              PhotonNetwork.method("get_LocalPlayer").invoke()
            );
            spawnedRig = null;
          }
        } else {
          if (spawnedRig == null) {
            spawnedRig = PhotonNetwork.method("Instantiate", 5).invoke(
              Il2Cpp.string("photonvr/Player"),
              getTransform(headCollider).method("get_position").invoke(),
              identityQuaternion,
              0,
              NULL
            );
            sendAllOutgoing();
          }
        }
      }
    }
  }
  //#region  Platforms
  let platColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
  const platColors: [number, number, number, number][] = [
    [0.0, 0.0, 0.0, 1.0],       // Black
    [9.0, 9.0, 9.0, 1.0],       // Bright white
    [9.0, 0.0, 0.0, 1.0],       // Red
    [0.0, 9.0, 0.0, 1.0],       // Green
    [0.0, 0.0, 9.0, 1.0],       // Blue
    [5.0, 5.0, 0.0, 1.0],       // Yellow
    [9.0, 0.5, 9.0, 1.0],       // Magenta
    [2.4, 7.5, 5.9, 1.0],       // Teal (Eucalyptus)
  ];
  let platL = null;
  let platR = null;
  let plater = 0;

  function Platforms() {
    if (leftGrab) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightGrab) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  function TriggerPlatforms() {
    if (leftTrigger) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightTrigger) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  function PlankPlatforms() {
    if (leftGrab) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightGrab) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  function TriggerPlankPlatforms() {
    if (leftTrigger) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightTrigger) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 1, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  //#endregion

  //#region  NoClip

  function Noclip() {
    if (rightTrigger && !previousNoclipKey) {
      toggleColliders(false);
    }

    if (!rightTrigger && previousNoclipKey) {
      toggleColliders(true);
    }

    previousNoclipKey = rightTrigger;
  }

  function toggleColliders(enabled) {
    const meshColliders = Object.method("FindObjectsOfType").inflate(MeshCollider).invoke();

    for (let i = 0; i < meshColliders.length; i++) {
      const meshCollider = meshColliders.get(i);
      meshCollider.method("set_enabled").invoke(enabled);
    }
  }

  //#endregion

  //#endregion

  //#region Misc

  function dumpServerInfo(): void {
    const PlayFabSettingsClass = Il2Cpp.domain.assembly("PlayFab").image.class("PlayFabSharedSettings");

    let settingsInstance: any = null;

    try {
      const instances = Il2Cpp.gc.choose(PlayFabSettingsClass);
      if (instances.length > 0) settingsInstance = instances[0];
    }
    catch (e1) {
      try {
        const instances = (PlayFabSettingsClass as any).instances;
        if (instances.length > 0) settingsInstance = instances[0];
      }
      catch (e2) { }
    }

    if (!settingsInstance) {
      try {
        const getProp = PlayFabSettingsClass.method("get_TitleId");
        const result = getProp.invoke();
        console.log("[PlayFab] TitleId (via getter): " + result);
      } catch (e3) {
        console.log("[DEBUG] Dumping all PlayFabSharedSettings fields:");
        PlayFabSettingsClass.fields.forEach((f: any) => {
          console.log("  [FIELD] " + f.name + " | static: " + f.isStatic + " | type: " + f.type.name);
          if (f.isStatic) {
            try {
              console.log("    value: " + f.value);
            } catch (e) {
              console.log("    value: <error reading> " + e);
            }
          }
        });

        console.log("[DEBUG] Dumping PlayFabSharedSettings methods:");
        PlayFabSettingsClass.methods.forEach((m: any) => {
          console.log("  [METHOD] " + m.name + " | static: " + m.isStatic);
        });
      }
    } else {
      console.log("[PlayFab] TitleId: " + settingsInstance.field("TitleId").value);
    }
  }

  //#endregion

  //#region OP

  function RigSpam() {
    if (rightGrab) {
      const now = Date.now();
      if (now - lastRunTime >= 0.1) {
        lastRunTime = now;
        const clonedrig = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("photonvr/Player"), getTransform(headCollider).method("get_position").invoke(), identityQuaternion, 0, NULL)
        const components = clonedrig.method("GetComponents", 1).inflate(Component).invoke();

        for (let i = 0; i < components.length; i++) {
          const component = components.get(i);
          const name = component.method("GetType", 0).invoke().method("get_Name").invoke().toString();

          if (name.includes("PhotonVRPlayer")) {
            setTimeout(function () {
              Destroy(component);
            }, 150)
          }
        }
      }
      sendAllOutgoing()
    }
  }

  function RigGun() {
    if (rightGrab) {
      const gunData = renderGun();
      const gunPointer = gunData.gunPointer;

      if (rightTrigger) {
        const pos = getTransform(gunPointer).method("get_position").invoke()
        const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("photonvr/Player"), pos, identityQuaternion, 0, NULL);

        const components = playerSpawned.method("GetComponents", 1).inflate(Component).invoke();

        for (let i = 0; i < components.length; i++) {
          const component = components.get(i);
          const name = component.method("GetType", 0).invoke().method("get_Name").invoke().toString();

          if (name.includes("PhotonVRPlayer")) {
            Destroy(component);
          }
        }
        sendAllOutgoing()
      };;
    }
  }

  function DoorSound() {
    const Animatronicssss = Object.method("FindObjectsOfType").inflate(Animatronics).invoke();
    for (let i = 0; i < Animatronicssss.length; i++) {
      const currentAnim = Animatronicssss.get(i)
      const randomIndex = randomInt(0, 2);
      currentAnim.method("RPC_PlayDoorClosedAudio").invoke(randomIndex)
    }
  }

  function setMaxPlayers(maxPlayers: number): void {
    const currentRoom = PhotonNetwork.field("CurrentRoom").value;

    if (!currentRoom) {
        console.log("not in a room");
        return;
    }

    currentRoom.method("set_MaxPlayers").invoke(maxPlayers);
  }

  function PrefabGun(spawnId: string) {
    if (rightGrab) {
      const gunData = renderGun();
      const gunPointer = gunData.gunPointer;

      if (rightTrigger) {
        const pos = getTransform(gunPointer).method("get_position").invoke()
        const Spawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(spawnId), pos, identityQuaternion, 0, NULL);
        sendAllOutgoing()
      };;
    }
  }

  function CrashAll() {
    for (let i = 0; i < 1500; i++) {
      const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
      Destroy(thingforlag)
    }
    sendAllOutgoing()
  }

  function LagAll() {
    const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
    Destroy(thingforlag)
    sendAllOutgoing()
  }

  function StrongerLagAll() {
    for (let i = 0; i < 300; i++) {
      const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
      Destroy(thingforlag)
    }
    sendAllOutgoing()
  }

  function LagSpikeAll() {
    for (let i = 0; i < 300; i++) {
      const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
      Destroy(thingforlag)
    }
    sendAllOutgoing()
  }

  function HardCrashAll() {
    for (let i = 0; i < 5000; i++) {
      const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
      Destroy(thingforlag)
    }
    sendAllOutgoing()
  }

  function ExtremeCrashAll() {
    for (let i = 0; i < 10000; i++) {
      const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
      Destroy(thingforlag)
    }
    sendAllOutgoing()
  }

  function DestroyAll() {
    const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
    if (others && others.length > 0) {
      for (let i = 0; i < others.length; i++) {
        const player = others.get(i);
        PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
        PhotonNetwork.method("DestroyPlayerObjects").invoke(player);
      }
    }
  }

  function Chaos(){
    DestroyAll()
    CrashAll()
    DestroyAll()
    CrashAll()
    DestroyAll()
    CrashAll()
    DestroyAll()
    CrashAll()
  }
  //#endregion

  //#endregion


  const buttons: ButtonInfo[][] = [

    [ // Home
      new ButtonInfo({
        buttonText: "Settings",
        method: () => currentCategory = 2,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Movement Mods",
        method: () => currentCategory = 3,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Name Mods",
        method: () => currentCategory = 4,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Rig Mods",
        method: () => currentCategory = 5,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "OP Mods",
        method: () => currentCategory = 6,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Prefab Mods",
        method: () => { currentCategory = 7 },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Expiremental Mods",
        method: () => { currentCategory = 8 },
        keepOn: false,
      }),
    ],

    [ // Menu Buttons
      new ButtonInfo({
        buttonText: "Leave",
        method: () => PhotonNetwork.method("LeaveRoom", 1).invoke(true),
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Home",
        method: () => {
          currentCategory = 0
          currentPage = 0
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "PreviousPage",
        method: () => {
          const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

          currentPage--;
          if (currentPage < 0)
            currentPage = lastPage;
        },
        keepOn: false
      }),
      new ButtonInfo({
        buttonText: "NextPage",
        method: () => {
          const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

          currentPage++;
          currentPage %= lastPage + 1;
        },
        keepOn: false
      })
    ],

    [ // Settings
      new ButtonInfo({
        buttonText: `Fly Speed+`,
        method: () => {
          flyspeed += 1
          reloadMenu();
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: `Fly Speed-`,
        method: () => {
          flyspeed -= 1
          reloadMenu();
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: `Fly Speed++`,
        method: () => {
          flyspeed += 2
          reloadMenu();
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: `Fly Speed--`,
        method: () => {
          flyspeed -= 2
          reloadMenu();
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Platform Color",
        method: () => {
          plater = (plater + 1) % platColors.length;
          platColor = platColors[plater];
        },
        keepOn: false,
      }),
    ],

    [ // Movement Mods
      new ButtonInfo({
        buttonText: "Fly [B]",
        method: () => {
          Fly()
        },
      }),

      new ButtonInfo({
        buttonText: "Trigger Fly [RT]",
        method: () => {
          TriggerFly()
        },
      }),

      new ButtonInfo({
        buttonText: "Platforms [G]",
        method: () => {
          Platforms()
        },
      }),

      new ButtonInfo({
        buttonText: "Trigger Platforms [T]",
        method: () => {
          TriggerPlatforms()
        },
      }),

      new ButtonInfo({
        buttonText: "Plank Platforms [G]",
        method: () => {
          PlankPlatforms()
        },
      }),

      new ButtonInfo({
        buttonText: "Trigger Plank Platforms [G]",
        method: () => {
          TriggerPlankPlatforms()
        },
      }),


      new ButtonInfo({
        buttonText: "Toggle Gravity",
        method: () => {
          const current = rigidbody.method("get_useGravity").invoke() as boolean;
          rigidbody.method("set_useGravity").invoke(!current);
        },
        keepOn: false
      }),

      new ButtonInfo({
        buttonText: "No Clip [T]",
        method: () => {
          Noclip()
        },
      }),
    ],

    [ // Misc Mods
      new ButtonInfo({
        buttonText: "Reset Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(""))
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Byteful On Top Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=30><sprite=12>Byteful On TOP!!!<sprite=12>"))
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "BIG Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=170%>BYTEMODS ON TOP"))
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "No Name [Blank]",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=1>"))
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "No Name [Size]",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=1>a"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "No Name [Underscores]",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("___"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Square Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("💻"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "GMBB name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("game modded by bytemods"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "ColonThree name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(":3"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Long Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Strobe Name",
        method: () => {
          StrobeName()
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Owner Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<color=yellow>[OWNER]</color>"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Rainbow Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<color=#ff0000>R</color><color=#ff7f00>a</color><color=#ffff00>i</color><color=#00ff00>n</color><color=#00bfff>b</color><color=#4b0082>o</color><color=#8b00ff>w</color>"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Extremely Big Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=999%>Modded using BYTEMODS!"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Bold Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<b>bold</b>"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Italic Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<i>italic</i>"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Strikethrough Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<s>strikethrough</s>"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "underline Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<u>underline</u>"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "I like styling name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<b>I</b> <i>like</i> <color=#ff0000>s</color><color=#ff5500>t</color><color=#ffaa00>y</color><color=#aaff00>l</color><color=#00ff55>i</color><color=#00aaff>n</color><color=#5500ff>g</color>"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Jmancurly Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("Jmancurly"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "VMT Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("VMT"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "Lines Name",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("I|I|I|I|I|I|I|I|I|I|I|I"))
        },
        keepOn: true,
      }),
    ],

    [ // Rig Mods
      new ButtonInfo({
        buttonText: "Ghost Rig [B]",
        method: () => {
          GhostRig()
        },
      }),

      new ButtonInfo({
        buttonText: "Invis Rig [B]",
        method: () => {
          InvisRig()
        },
      }),
    ],

    [ // OP Mods
      new ButtonInfo({
        buttonText: "Set Master",
        method: () => { PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke()) },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Rig Spam [G]",
        method: () => {
          RigSpam()
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Rig Gun [G]",
        method: () => {
          RigGun()
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Door Spam (Audio)",
        method: () => {
          DoorSound()
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Crash All",
        method: () => {
          CrashAll()
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Invis All",
        method: () => {
          DestroyAll()
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Hard Crash All",
        method: () => {
          HardCrashAll()
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Extreme Crash All",
        method: () => {
          ExtremeCrashAll()
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Chaos",
        method: () => {
          Chaos()
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Blind All [Name]",
        method: () => {
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=300%>#"))
        },
        keepOn: true,
      }),
      new ButtonInfo({
        buttonText: "10 Player Lobby [M]",
        method: () => {
          setMaxPlayers(10)
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "20 Player Lobby [M]",
        method: () => {
          setMaxPlayers(20)
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "50 Player Lobby [M]",
        method: () => {
          setMaxPlayers(50)
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "100 Player Lobby [M]",
        method: () => {
          setMaxPlayers(100)
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "200 Player Lobby [M]",
        method: () => {
          setMaxPlayers(200)
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "500 Player Lobby [M]",
        method: () => {
          setMaxPlayers(500)
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "1000 Player Lobby [M]",
        method: () => {
          setMaxPlayers(1000)
        },
        keepOn: false,
      }),
    ],
    [ // Prefabs
      new ButtonInfo({
        buttonText: "ZomBear Gun [G]",
        method: () => {
          PrefabGun("ZomBear")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "ZomBunny Gun [G]",
        method: () => {
          PrefabGun("ZomBunny")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Boy Gun [G]",
        method: () => {
          PrefabGun("Boy")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Hellephant Gun [G]",
        method: () => {
          PrefabGun("Hellephant")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Character Gun [G]",
        method: () => {
          PrefabGun("Character")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Spaceship Gun [G] [OP]",
        method: () => {
          PrefabGun("Spaceship")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "BigAsteroid Gun [G] [NW]",
        method: () => {
          PrefabGun("BigAsteroid")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "SmallAsteroid Gun [G] [NW]",
        method: () => {
          PrefabGun("SmallAsteroid")
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Confetti Gun [G] [NW]",
        method: () => {
          PrefabGun("BPU")
        },
        keepOn: true,
      }),
    ],

    [ // expiremental mods
      new ButtonInfo({
        buttonText: "Get PlayFab Title ID",
        method: () => {
          dumpServerInfo()
        },
        keepOn: false,
      }),
    ]
  ];

  let buttonMap: Map<string, ButtonInfo> = new Map();
  buttons.flat().forEach(button => {
    buttonMap.set(button.buttonText, button);
  });

  function getIndex(buttonText: string): ButtonInfo {
    return buttonMap.get(buttonText);
  }

  const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
  ButtonActivation.implementation = function (collider) {
    const rawName = this.method("get_name").invoke().toString();

    if (rawName.length > 1 && rawName[1] == "@") {
      if (collider.handle.equals(referenceCollider.handle)) {
        const goName = rawName.substring(2, rawName.length - 1);
        const _time = Time.method("get_time").invoke();

        if (_time > buttonClickDelay) {
          buttonClickDelay = _time + 0.2;

          const button = getIndex(goName)
          if (button) {
            if (button.keepOn) {
              button.enabled = !button.enabled;

              if (button?.enabled) {
                button.enableMethod?.();
              } else {
                button?.disableMethod?.();
              }

            } else {
              button?.method?.();
            }

            reloadMenu();
          }
        }
      }

      return;
    }

    return this.method("OnTriggerEnter").invoke(collider);
  };

  const LateUpdate = GTPlayer.method("Update");

  LateUpdate.implementation = function () {

    OVRInputHandler.update();

    leftPrimary = OVRInputHandler.leftControllerPrimaryButton
    leftSecondary = OVRInputHandler.leftControllerSecondaryButton;

    rightPrimary = OVRInputHandler.rightControllerPrimaryButton;
    rightSecondary = OVRInputHandler.rightControllerSecondaryButton;

    leftGrab = OVRInputHandler.leftGrab;
    rightGrab = OVRInputHandler.rightGrab;

    leftTrigger = OVRInputHandler.leftControllerTriggerButton;
    rightTrigger = OVRInputHandler.rightControllerTriggerButton;

    deltaTime = Time.method("get_deltaTime").invoke();
    time = Time.method("get_time").invoke();

    if (leftSecondary) {
      if (menu == null) {
        renderMenu();
      } else {
        recenterMenu();
      }
    } else {
      if (menu != null) {
        Destroy(menu);
        menu = null;
      }
    }

    if (menu == null) {
      if (reference != null) {
        Destroy(reference);
        reference = null;
      }
    } else {
      if (reference == null) {
        renderReference();
      }
    }

    try {
      if (GunPointer != null) {
        if (!(GunPointer.method("get_activeSelf").invoke())) {
          Destroy(GunPointer);
          GunPointer = null;
        }
        else
          GunPointer.method("SetActive").invoke(false);
      }

      let lineObj = GunLine.method("get_gameObject").invoke();
      if (lineObj != null) {
        if (!(lineObj.method("get_activeSelf").invoke())) {
          Destroy(lineObj);
          GunLine = null;
        }
        else
          lineObj.method("SetActive").invoke(false);
      }
    } catch { }

    buttons.flat()
      .filter(button => button.enabled)
      .forEach(button => {
        if (button.method) {
          try {
            button.method();
          } catch (error) {
            console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
            console.error('Error stack:', error.stack);
            console.error('Button object:', button);

            if (error.stack) {
              const stackLines = error.stack.split('\n');
              if (stackLines.length > 1) {
                console.error('Error occurred at:', stackLines[1].trim());
              }
            }
          }
        }
      });

    return LateUpdate.invoke();
  };
  const TopBanner = `

      :::::::::  :::   ::: ::::::::::: ::::::::::   :::   :::    ::::::::  :::::::::   ::::::::          :::::::::   ::::::::   :::::::: ::::::::::: 
     :+:    :+: :+:   :+:     :+:     :+:         :+:+: :+:+:  :+:    :+: :+:    :+: :+:    :+:         :+:    :+: :+:    :+: :+:    :+:    :+:      
    +:+    +:+  +:+ +:+      +:+     +:+        +:+ +:+:+ +:+ +:+    +:+ +:+    +:+ +:+                +:+    +:+ +:+    +:+ +:+    +:+    +:+       
   +#++:++#+    +#++:       +#+     +#++:++#   +#+  +:+  +#+ +#+    +:+ +#+    +:+ +#++:++#++         +#++:++#:  +#+    +:+ +#+    +:+    +#+        
  +#+    +#+    +#+        +#+     +#+        +#+       +#+ +#+    +#+ +#+    +#+        +#+         +#+    +#+ +#+    +#+ +#+    +#+    +#+         
 #+#    #+#    #+#        #+#     #+#        #+#       #+# #+#    #+# #+#    #+# #+#    #+#         #+#    #+# #+#    #+# #+#    #+#    #+#          
#########     ###        ###     ########## ###       ###  ########  #########   ########          ###    ###  ########   ########     ###           
⌟--------------------------------------------------------------------------------------------------------------------------------------------------⌞
|                                             ByteMods ROOT PORT | Teddy's Pizzeria | byteful.is-a.dev                                             |
⌝--------------------------------------------------------------------------------------------------------------------------------------------------⌜

`;

  console.log(`Compiled ${new Date().toISOString()}`)
  console.log(TopBanner)
  console.log("THANK YOU FOR USING BYTEMODS ROOT PORT!")
  console.log("This one is specifically for the game \"Teddy's Pizzeria\"!")
  console.log("If you paid for this, you got SCAMMED.")
  console.log("Freely available on the ByteMods server: https://discord.gg/a54WQbSq2M")
  console.log("byteful.is-a.dev")

}, "main");